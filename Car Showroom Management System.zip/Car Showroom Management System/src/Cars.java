/**
 * Represents a car.
 * This class inherits from Showroom to associate a car with a showroom.
 * Note: A better design might use composition instead of inheritance here.
 */
public class Cars extends Showroom implements Utility {
    // Class members for car details
    String car_name;
    String car_color;
    String car_fuel_type;
    int car_price;
    String car_type;
    String car_transmission;

    /**
     * Parameterized constructor to initialize a Cars object.
     *
     * @param car_name         The name of the car.
     * @param car_color        The color of the car.
     * @param car_fuel_type    The fuel type (e.g., Petrol, Diesel).
     * @param car_price        The price of the car.
     * @param car_type         The car type (e.g., Sedan, SUV).
     * @param car_transmission The transmission type (e.g., Automatic, Manual).
     */
    public Cars(String car_name, String car_color, String car_fuel_type, int car_price, String car_type, String car_transmission) {
        this.car_name = car_name;
        this.car_color = car_color;
        this.car_fuel_type = car_fuel_type;
        this.car_price = car_price;
        this.car_type = car_type;
        this.car_transmission = car_transmission;
    }

    /**
     * Returns a formatted string with the car's details.
     *
     * @return A formatted string.
     */
    @Override
    public String get_details() {
        return "Name: " + car_name + "\n" +
                "Color: " + car_color + "\n" +
                "Fuel Type: " + car_fuel_type + "\n" +
                "Price: " + car_price + "\n" +
                "Car Type: " + car_type + "\n" +
                "Transmission: " + car_transmission;
    }
}