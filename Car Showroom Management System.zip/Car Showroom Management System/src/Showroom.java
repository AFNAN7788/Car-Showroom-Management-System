/**
 * Represents a showroom.
 * This class holds details about a specific showroom location.
 */
public class Showroom implements Utility {
    // Class members to store showroom details
    String showroom_name;
    String showroom_address;
    int total_employees;
    int total_cars_in_stock = 0;
    String manager_name;

    /**
     * Default constructor.
     */
    public Showroom() {
        // Default constructor is needed for the subclasses
    }

    /**
     * Parameterized constructor to initialize a Showroom object.
     *
     * @param showroom_name       The name of the showroom.
     * @param showroom_address    The address of the showroom.
     * @param manager_name        The name of the manager.
     * @param total_employees     The total number of employees.
     * @param total_cars_in_stock The number of cars in stock.
     */
    public Showroom(String showroom_name, String showroom_address, String manager_name, int total_employees, int total_cars_in_stock) {
        this.showroom_name = showroom_name;
        this.showroom_address = showroom_address;
        this.manager_name = manager_name;
        this.total_employees = total_employees;
        this.total_cars_in_stock = total_cars_in_stock;
    }

    /**
     * Returns a formatted string with the showroom's details.
     *
     * @return A formatted string.
     */
    @Override
    public String get_details() {
        return "Showroom Name: " + showroom_name + "\n" +
                "Showroom Address: " + showroom_address + "\n" +
                "Manager Name: " + manager_name + "\n" +
                "Total Employees: " + total_employees + "\n" +
                "Total Cars In Stock: " + total_cars_in_stock;
    }
}