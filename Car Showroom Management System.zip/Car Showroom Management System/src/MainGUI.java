import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

/**
 * The main class for the Showroom Management System GUI.
 * This class creates the main window and all the panels for interacting with the system.
 */
public class MainGUI extends JFrame {

    // CardLayout for switching between panels
    private CardLayout cardLayout = new Layout();
    private JPanel mainPanel = new JPanel(cardLayout);

    // Data storage using ArrayLists for flexibility
    private List<Showroom> showrooms = new ArrayList<>();
    private List<Employees> employees = new ArrayList<>();
    private List<Cars> cars = new ArrayList<>();

    // Panels for different functionalities
    private JPanel menuPanel;
    private JPanel addShowroomPanel;
    private JPanel addEmployeePanel;
    private JPanel addCarPanel;
    private JPanel viewShowroomsPanel;
    private JPanel viewEmployeesPanel;
    private JPanel viewCarsPanel;

    // Text areas to display lists of items
    private JTextArea showroomsTextArea = new JTextArea(20, 50);
    private JTextArea employeesTextArea = new JTextArea(20, 50);
    private JTextArea carsTextArea = new JTextArea(20, 50);

    /**
     * Inner class for a JPanel with a background image.
     */
    class ImagePanel extends JPanel {
        private Image backgroundImage;

        public ImagePanel(String imageUrl) {
            try {
                // Load the image from a URL
                backgroundImage = ImageIO.read(new URL(imageUrl));
            } catch (IOException e) {
                System.err.println("Couldn't find or load the background image: " + imageUrl);
                e.printStackTrace();
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // Draw the image, scaling it to the panel's size
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, this.getWidth(), this.getHeight(), this);
            }
        }
    }


    public MainGUI() {
        setTitle("Showroom Management System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create all the panels
        createMenuPanel();
        createAddShowroomPanel();
        createAddEmployeePanel();
        createAddCarPanel();
        createViewShowroomsPanel();
        createViewEmployeesPanel();
        createViewCarsPanel();

        // Add panels to the main card layout panel
        mainPanel.add(menuPanel, "menu");
        mainPanel.add(addShowroomPanel, "addShowroom");
        mainPanel.add(addEmployeePanel, "addEmployee");
        mainPanel.add(addCarPanel, "addCar");
        mainPanel.add(viewShowroomsPanel, "viewShowrooms");
        mainPanel.add(viewEmployeesPanel, "viewEmployees");
        mainPanel.add(viewCarsPanel, "viewCars");

        // Show the menu panel first
        cardLayout.show(mainPanel, "menu");

        add(mainPanel);
    }

    private void createMenuPanel() {
        // Use the custom ImagePanel for the background
        menuPanel = new ImagePanel("https://images.unsplash.com/photo-1552519507-da3b142c6e3d?q=80&w=2070&auto=format&fit=crop");
        menuPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        menuPanel.setLayout(new BorderLayout(20, 20));

        // Title Label
        JLabel titleLabel = new JLabel("Showroom Management System", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 32));
        titleLabel.setForeground(Color.WHITE);

        // Buttons for main menu
        JButton btnAddShowroom = new JButton("Add Showroom");
        JButton btnAddEmployee = new JButton("Add Employee");
        JButton btnAddCar = new JButton("Add Car");
        JButton btnViewShowrooms = new JButton("View Showrooms");
        JButton btnViewEmployees = new JButton("View Employees");
        JButton btnViewCars = new JButton("View Cars");
        JButton btnExit = new JButton("Exit");

        // Style the buttons
        Font buttonFont = new Font("Arial", Font.BOLD, 14);
        JButton[] buttons = {btnAddShowroom, btnAddEmployee, btnAddCar, btnViewShowrooms, btnViewEmployees, btnViewCars, btnExit};
        for (JButton button : buttons) {
            button.setFont(buttonFont);
            button.setBackground(new Color(60, 63, 65));
            button.setForeground(Color.WHITE);
            button.setFocusPainted(false);
            button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        }


        // Action Listeners for buttons
        btnAddShowroom.addActionListener(e -> cardLayout.show(mainPanel, "addShowroom"));
        btnAddEmployee.addActionListener(e -> cardLayout.show(mainPanel, "addEmployee"));
        btnAddCar.addActionListener(e -> cardLayout.show(mainPanel, "addCar"));

        btnViewShowrooms.addActionListener(e -> {
            updateShowroomsView();
            cardLayout.show(mainPanel, "viewShowrooms");
        });

        btnViewEmployees.addActionListener(e -> {
            updateEmployeesView();
            cardLayout.show(mainPanel, "viewEmployees");
        });

        btnViewCars.addActionListener(e -> {
            updateCarsView();
            cardLayout.show(mainPanel, "viewCars");
        });

        btnExit.addActionListener(e -> System.exit(0));

        // Add components to panel
        JPanel buttonPanel = new JPanel(new GridLayout(3, 2, 15, 15));
        buttonPanel.setOpaque(false); // Make button panel transparent
        buttonPanel.add(btnAddShowroom);
        buttonPanel.add(btnViewShowrooms);
        buttonPanel.add(btnAddEmployee);
        buttonPanel.add(btnViewEmployees);
        buttonPanel.add(btnAddCar);
        buttonPanel.add(btnViewCars);

        menuPanel.add(titleLabel, BorderLayout.NORTH);
        menuPanel.add(buttonPanel, BorderLayout.CENTER);

        JPanel exitPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        exitPanel.setOpaque(false);
        exitPanel.add(btnExit);
        menuPanel.add(exitPanel, BorderLayout.SOUTH);
    }

    private void createAddShowroomPanel() {
        addShowroomPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;

        addShowroomPanel.add(new JLabel("Showroom Name:"), gbc);
        gbc.gridy++;
        addShowroomPanel.add(new JLabel("Address:"), gbc);
        gbc.gridy++;
        addShowroomPanel.add(new JLabel("Manager Name:"), gbc);
        gbc.gridy++;
        addShowroomPanel.add(new JLabel("Total Employees:"), gbc);
        gbc.gridy++;
        addShowroomPanel.add(new JLabel("Cars in Stock:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;

        JTextField nameField = new JTextField(20);
        addShowroomPanel.add(nameField, gbc);
        gbc.gridy++;
        JTextField addressField = new JTextField(20);
        addShowroomPanel.add(addressField, gbc);
        gbc.gridy++;
        JTextField managerField = new JTextField(20);
        addShowroomPanel.add(managerField, gbc);
        gbc.gridy++;
        JTextField employeesField = new JTextField(20);
        addShowroomPanel.add(employeesField, gbc);
        gbc.gridy++;
        JTextField carsField = new JTextField(20);
        addShowroomPanel.add(carsField, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton saveButton = new JButton("Save");
        JButton backButton = new JButton("Back to Menu");
        buttonPanel.add(saveButton);
        buttonPanel.add(backButton);
        addShowroomPanel.add(buttonPanel, gbc);

        backButton.addActionListener(e -> cardLayout.show(mainPanel, "menu"));
        saveButton.addActionListener(e -> {
            try {
                String name = nameField.getText();
                String address = addressField.getText();
                String manager = managerField.getText();
                int totalEmployees = Integer.parseInt(employeesField.getText());
                int totalCars = Integer.parseInt(carsField.getText());

                showrooms.add(new Showroom(name, address, manager, totalEmployees, totalCars));
                JOptionPane.showMessageDialog(this, "Showroom added successfully!");

                // Clear fields
                nameField.setText("");
                addressField.setText("");
                managerField.setText("");
                employeesField.setText("");
                carsField.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid numbers for employees and cars.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    // Helper method to create a generic "View" panel
    private JPanel createViewPanel(String title, JTextArea textArea) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));

        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);

        JButton backButton = new JButton("Back to Menu");
        backButton.addActionListener(e -> cardLayout.show(mainPanel, "menu"));

        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(backButton, BorderLayout.SOUTH);

        return panel;
    }

    private void createViewShowroomsPanel() {
        viewShowroomsPanel = createViewPanel("Showroom List", showroomsTextArea);
    }

    private void updateShowroomsView() {
        showroomsTextArea.setText("");
        if (showrooms.isEmpty()) {
            showroomsTextArea.setText("No showrooms have been added yet.");
        } else {
            for (Showroom s : showrooms) {
                showroomsTextArea.append(s.get_details() + "\n\n--------------------\n\n");
            }
        }
        showroomsTextArea.setCaretPosition(0); // Scroll to top
    }

    // Similar createAdd...Panel, createView...Panel, and update...View methods for Employees and Cars

    private void createAddEmployeePanel() {
        addEmployeePanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;

        addEmployeePanel.add(new JLabel("Employee Name:"), gbc);
        gbc.gridy++;
        addEmployeePanel.add(new JLabel("Age:"), gbc);
        gbc.gridy++;
        addEmployeePanel.add(new JLabel("Department:"), gbc);
        gbc.gridy++;
        addEmployeePanel.add(new JLabel("Showroom Name:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField nameField = new JTextField(20);
        addEmployeePanel.add(nameField, gbc);
        gbc.gridy++;
        JTextField ageField = new JTextField(20);
        addEmployeePanel.add(ageField, gbc);
        gbc.gridy++;
        JTextField deptField = new JTextField(20);
        addEmployeePanel.add(deptField, gbc);
        gbc.gridy++;
        JTextField showroomField = new JTextField(20);
        addEmployeePanel.add(showroomField, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton saveButton = new JButton("Save");
        JButton backButton = new JButton("Back to Menu");
        buttonPanel.add(saveButton);
        buttonPanel.add(backButton);
        addEmployeePanel.add(buttonPanel, gbc);

        backButton.addActionListener(e -> cardLayout.show(mainPanel, "menu"));
        saveButton.addActionListener(e -> {
            try {
                employees.add(new Employees(nameField.getText(), Integer.parseInt(ageField.getText()), deptField.getText(), showroomField.getText()));
                JOptionPane.showMessageDialog(this, "Employee added successfully!");
                nameField.setText("");
                ageField.setText("");
                deptField.setText("");
                showroomField.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number for age.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void createAddCarPanel() {
        addCarPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;

        addCarPanel.add(new JLabel("Car Name:"), gbc);
        gbc.gridy++;
        addCarPanel.add(new JLabel("Color:"), gbc);
        gbc.gridy++;
        addCarPanel.add(new JLabel("Fuel Type (Petrol/Diesel):"), gbc);
        gbc.gridy++;
        addCarPanel.add(new JLabel("Price:"), gbc);
        gbc.gridy++;
        addCarPanel.add(new JLabel("Type (Sedan/SUV/Hatchback):"), gbc);
        gbc.gridy++;
        addCarPanel.add(new JLabel("Transmission (Automatic/Manual):"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField nameField = new JTextField(20);
        addCarPanel.add(nameField, gbc);
        gbc.gridy++;
        JTextField colorField = new JTextField(20);
        addCarPanel.add(colorField, gbc);
        gbc.gridy++;
        JTextField fuelField = new JTextField(20);
        addCarPanel.add(fuelField, gbc);
        gbc.gridy++;
        JTextField priceField = new JTextField(20);
        addCarPanel.add(priceField, gbc);
        gbc.gridy++;
        JTextField typeField = new JTextField(20);
        addCarPanel.add(typeField, gbc);
        gbc.gridy++;
        JTextField transmissionField = new JTextField(20);
        addCarPanel.add(transmissionField, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton saveButton = new JButton("Save");
        JButton backButton = new JButton("Back to Menu");
        buttonPanel.add(saveButton);
        buttonPanel.add(backButton);
        addCarPanel.add(buttonPanel, gbc);

        backButton.addActionListener(e -> cardLayout.show(mainPanel, "menu"));
        saveButton.addActionListener(e -> {
            try {
                cars.add(new Cars(nameField.getText(), colorField.getText(), fuelField.getText(), Integer.parseInt(priceField.getText()), typeField.getText(), transmissionField.getText()));
                JOptionPane.showMessageDialog(this, "Car added successfully!");
                nameField.setText("");
                colorField.setText("");
                fuelField.setText("");
                priceField.setText("");
                typeField.setText("");
                transmissionField.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number for price.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void createViewEmployeesPanel() {
        viewEmployeesPanel = createViewPanel("Employee List", employeesTextArea);
    }

    private void updateEmployeesView() {
        employeesTextArea.setText("");
        if(employees.isEmpty()){
            employeesTextArea.setText("No employees have been added yet.");
        } else {
            for (Employees emp : employees) {
                employeesTextArea.append(emp.get_details() + "\n\n--------------------\n\n");
            }
        }
        employeesTextArea.setCaretPosition(0);
    }

    private void createViewCarsPanel() {
        viewCarsPanel = createViewPanel("Car List", carsTextArea);
    }

    private void updateCarsView() {
        carsTextArea.setText("");
        if(cars.isEmpty()){
            carsTextArea.setText("No cars have been added yet.");
        } else {
            for (Cars car : cars) {
                carsTextArea.append(car.get_details() + "\n\n--------------------\n\n");
            }
        }
        carsTextArea.setCaretPosition(0);
    }

    public static void main(String[] args) {
        // Run the GUI on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            new MainGUI().setVisible(true);
        });
    }

    private class Layout extends CardLayout {
    }
}

