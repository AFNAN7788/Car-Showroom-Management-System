import java.util.UUID;

/**
 * Represents an employee.
 * This class inherits from Showroom to associate an employee with a showroom.
 * Note: A better design might use composition instead of inheritance here.
 */
public class Employees extends Showroom implements Utility {
    // Class members for employee details
    String emp_id;
    String emp_name;
    int emp_age;
    String emp_department;

    /**
     * Parameterized constructor to initialize an Employees object.
     *
     * @param emp_name       The name of the employee.
     * @param emp_age        The age of the employee.
     * @param emp_department The department of the employee.
     * @param showroom_name  The name of the showroom where the employee works.
     */
    public Employees(String emp_name, int emp_age, String emp_department, String showroom_name) {
        // Generate a unique ID for the employee
        this.emp_id = UUID.randomUUID().toString();
        this.emp_name = emp_name;
        this.emp_age = emp_age;
        this.emp_department = emp_department;
        this.showroom_name = showroom_name; // Inherited from Showroom
    }

    /**
     * Returns a formatted string with the employee's details.
     *
     * @return A formatted string.
     */
    @Override
    public String get_details() {
        return "ID: " + emp_id + "\n" +
                "Name: " + emp_name + "\n" +
                "Age: " + emp_age + "\n" +
                "Department: " + emp_department + "\n" +
                "Showroom Name: " + showroom_name;
    }
}