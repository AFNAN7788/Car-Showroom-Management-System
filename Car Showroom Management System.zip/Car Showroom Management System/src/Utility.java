
public interface Utility {
    /**
     * Returns a formatted string containing the details of the object.
     * This will be used to display information in the GUI.
     *
     * @return A formatted String with the object's details.
     */
    String get_details();
}